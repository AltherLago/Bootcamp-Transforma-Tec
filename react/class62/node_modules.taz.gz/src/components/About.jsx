import React from 'react';

export default function About(){

    return (
        <div>
            <h3>About us</h3>
        </div>
    )

}
