export default function Expenses(){
  return(
    <main>
      <h3 style={{ padding: '1rem 0' }}>Expenses</h3>
    </main>
  )
}
